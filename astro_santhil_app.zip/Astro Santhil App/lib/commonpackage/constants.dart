import 'package:flutter/material.dart';

const EdgeInsetsGeometry kAlignedButtonPadding = EdgeInsetsDirectional.only(start: 16.0, end: 4.0);
const EdgeInsets kUnalignedButtonPadding = EdgeInsets.zero;
